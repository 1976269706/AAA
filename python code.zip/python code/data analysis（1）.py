# -*- coding: utf-8 -*-
"""
Created on Mon Apr 26 19:46:21 2021

@author: lenovo
"""
import pandas as pd

import numpy as np
import matplotlib.pyplot as plt
import sklearn
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.metrics import roc_auc_score
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier as rfc
from sklearn.metrics import f1_score
from sklearn.metrics import precision_score as P
from sklearn.metrics import recall_score as R
from sklearn.metrics import confusion_matrix as CM
from sklearn.model_selection import cross_val_predict
from sklearn.decomposition import PCA
data=pd.read_csv("E:/肺实质分割/data1.csv",encoding='gbk')
mean=data.mean()
std = data.std()
range_low = mean-3*std
range_high = mean+3*std
new_data = data
num=0
'''以3*detal准则为依据删除异常值'''
for i in range(726):  #行
    for j in range(11):  #属性
        if range_low[j] > data.iloc[i,j] or data.iloc[i,j] > range_high[j] or data.iloc[i,4] ==0 or data.iloc[i,5] ==0:
            print('i',i)
            new_data = new_data.drop([i],axis=0)
            num = num+1
            print('num:',num)
            break
data = new_data
data=data[~(data['power'].isin([0]) & data['DBC'].isin([2]))]
data.apply(lambda x : (x-np.min(x))/(np.max(x)-np.min(x)))


data_train,data_test = train_test_split(data,test_size=0.2)#random_state=1234
col_names = data.columns
x = data_train[col_names[0:-1]]  # 自变量
y = data_train[col_names[-1]]  # 因变量
model = SVC(kernel = "rbf")  
model.fit(x, y)
x_test = data_test[col_names[0:-1]]  
y_test = data_test[col_names[-1]]
predict = model.predict(x_test)  # 预测值
print(P(y_test, predict))#准确率
'''
pca=PCA(n_components=2)
X_pca=pca.fit_transform(data[col_names[0:-1]])
x_list=[]
y_list=[]
for i in range(len(X_pca)):
        x_list.append(X_pca[i][0])
        y_list.append(X_pca[i][1])
fig=plt.figure()
ax1=fig.add_subplot(2,2,1)
ax1.scatter(x_list[0:287],y_list[0:287],s=20,color='red')
ax1.scatter(x_list[287:],y_list[287:],s=20,color='green')

from sklearn.ensemble import RandomForestRegressor
model = RandomForestRegressor(random_state=2, max_depth=15)
data=pd.get_dummies(data)
model.fit(data[col_names[0:-1]],data[col_names[-1]] )
features = data.columns
importances = model.feature_importances_
indices = np.argsort(importances[0:6]) # top 15 features
plt.title('Feature Importances')
plt.rcParams['font.sans-serif']='SimHei'#将字体设置为中文
plt.rcParams['axes.unicode_minus']=False#解决负号显示问题
plt.barh(range(len(indices)), importances[indices], color='b', align='center')
plt.yticks(range(len(indices)), [features[i] for i in indices])
plt.xlabel('Relative Importance')
plt.show()
'''