# -*- coding: utf-8 -*-
"""
Created on Mon Mar  1 21:19:57 2021

@author: lenovo
"""

import os
from PIL import Image
fileName = os.listdir('E:\\1\\CT_NonCOVID\\')
width = 512
height = 512
os.mkdir('E:\\1\\CT_NonCOVID(2)\\')
for img in fileName:
    pic = Image.open('E:\\1\\CT_NonCOVID\\' + img)
    newpic = pic.resize((width, height),Image.ANTIALIAS)
    print (newpic)
    newpic.save('E:\\1\\CT_NonCOVID(2)\\'+img)