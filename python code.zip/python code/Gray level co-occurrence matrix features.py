# -*- coding: utf-8 -*-
"""
Created on Thu Apr 29 16:41:58 2021

@author: lenovo
"""
#import cv2
import math
import numpy as np
from PIL import Image
import os
from skimage import io
'''
# 转换为灰度图像并且降低图片分辨率
img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) 
img_gray = cv2.resize(img_gray, (552, 1080))    

img_gray= np.array(Image.open("E:\\1\\CT_NonCOVID(1)_肺实质\\3.jpg"))

img_gray1= np.array(Image.open("E:\\1\\CT_COVID(1)_肺实质\\2020.01.24.919183-p27-134.png"))
'''
#灰度共生矩阵
def glcm(arr, d_x, d_y, gray_level=16):
    # 计算并返回归一化后的灰度共生矩阵
    max_gray = arr.max()
        
    height, width = arr.shape
    arr = arr.astype(np.float64)  # 将uint8类型转换为float64，避免数据失真
    # 若灰度级数大于gray_level，则将图像的灰度级缩小至gray_level，减小灰度共生矩阵的大小。量化后灰度值范围：0 ~ gray_level - 1
    arr = arr * (gray_level - 1) // max_gray  
    ret = np.zeros([gray_level, gray_level])
    for j in range(height - abs(d_y)):
        for i in range(width - abs(d_x)): 
            rows = arr[j][i].astype(int)
            cols = arr[j + d_y][i + d_x].astype(int)
            ret[rows][cols] += 1
    if d_x >= d_y:
        # 归一化, 水平方向或垂直方向
        ret = ret / float(height * (width - 1))  
    else:
        # 归一化, 45度或135度方向
        ret = ret / float((height - 1) * (width - 1))  

    return ret

'''
# 四个方向的共生矩阵
glcm_0 = glcm(img_gray, 1, 0)  # 水平方向
glcm_45 = glcm(img_gray, 1, 1)  # 45度方向
glcm_90 = glcm(img_gray, 0, 1)  # 垂直方向
glcm_135 = glcm(img_gray, -1, 1)  # 135度方向
'''
# 计算能量
def power(array):
    rows, cols = array.shape
    pow = 0
    for i in range(rows):
        for j in range(cols):
            pow += np.square(array[i][j])

    return pow

# 计算对比度
def duibidu(array):
    rows, cols = array.shape
    duibidu = 0
    for i in range(rows):
        for j in range(cols):
            # duibidu += {np.square{abs(i-j)}}*array[i, j]
            duibidu += np.square(abs(i - j))*array[i, j]
    return duibidu

# 计算最大概率值
def maxp(array):
    a = array[0, 0]
    rows, cols = array.shape
    for i in range(rows):
        for j in range(cols):
            if a <= array[i, j]:
                a = array[i, j]
            else:
                a = a
    return a

# 计算均匀度
def junyundu(array):
    rows, cols = array.shape
    junyun = 0
    for i in range(rows):
        for j in range(cols):
            junyun += array[i, j]/(1+abs(i-j))

    return junyun

#计算熵
def shang(array):
    rows, cols = array.shape
    a = 0
    for i in range(rows):
        for j in range(cols):
            if array[i, j] != 0:
                a += array[i, j]*(math.log(array[i, j], 2))
            else:
                continue
    return -a


import os
A_1=[];A_2=[]
B_1=[];B_2=[]
C_1=[];C_2=[]
D_1=[];D_2=[]
path = 'E:\\1\\新建文件夹 (2)\\' 
img_path = sorted([os.path.join(path, name) for name in os.listdir(path) if name.endswith('.jpg')])
for i in range(len(img_path)):
    img_gray= np.array(Image.open(img_path[i]))
    if img_gray.max()==0:
        A_1.append(0)
        A_2.append(0)
        B_1.append(0)
        B_2.append(0)
        C_1.append(0)
        C_2.append(0)
        D_1.append(0)
        D_2.append(0)
    else:
        glcm_0 = glcm(img_gray, 1, 0)  # 水平方向
        glcm_45 = glcm(img_gray, 1, 1)  # 45度方向
        glcm_90 = glcm(img_gray, 0, 1)  # 垂直方向
        glcm_135 = glcm(img_gray, -1, 1)  # 135度方向
        data1=[power(glcm_0),power(glcm_45),power(glcm_90),power(glcm_135)]
        variance1 = np.var(data1)
        mean1=np.mean(data1)
        A_1.append(mean1)
        A_2.append(str(variance1))
        data2=[duibidu(glcm_0),duibidu(glcm_45),duibidu(glcm_90),duibidu(glcm_135)]
        variance2= np.var(data2)
        mean2=np.mean(data2)
        B_1.append(mean2)
        B_2.append(str(variance2))
        data3=[junyundu(glcm_0),junyundu(glcm_45),junyundu(glcm_90),junyundu(glcm_135)]
        variance3= np.var(data3)
        mean3=np.mean(data3)
        C_1.append(mean3)
        C_2.append(str(variance3))
        data4=[shang(glcm_0),shang(glcm_45),shang(glcm_90),shang(glcm_135)]
        variance4= np.var(data4)
        mean4=np.mean(data4)
        D_1.append(mean4)
        D_2.append(str(variance4))
    
    
    
    

          
from pandas.core.frame import DataFrame

data={"a_1" : A_1,
      "a_2" : A_2,
      "b_1" : B_1,
      "b_2" : B_2,
      "c_1" : C_1,
      "c_2" : C_2,
      "d_1" : D_1,
      "d_2" : D_2}#将列表a，b转换成字典
data=DataFrame(data)#将字典转换成为数据框
data.to_csv("E:\\1\\新建文件夹_2.csv")













