# -*- coding: utf-8 -*-
"""
Created on Mon Mar  8 14:17:02 2021

@author: lenovo
"""

import pandas as pd

import numpy as np
import matplotlib.pyplot as plt
import sklearn
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.metrics import roc_auc_score
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier as rfc
from sklearn.metrics import f1_score
from sklearn.metrics import precision_score as P
from sklearn.metrics import recall_score as R
from sklearn.metrics import confusion_matrix as CM
from sklearn.model_selection import cross_val_predict
from scipy import stats
def t_test(data1, data2):
    print(stats.levene(data1, data2)) #如果返回结果的p值远大于0.05，那么我们认为两总体具有方差齐性。
    #如果两总体不具有方差齐性，需要加上参数equal_val并设定为False。
    print (stats.ttest_ind(data1, data2, equal_var=True))


data=pd.read_csv("E:/肺实质分割/data1.csv",encoding='gbk')
mean=data.mean()
std = data.std()
range_low = mean-3*std
range_high = mean+3*std
new_data = data
num=0
'''以3*detal准则为依据删除异常值'''
for i in range(726):  #行
    for j in range(19):  #属性
        if range_low[j] > data.iloc[i,j] or data.iloc[i,j] > range_high[j] or data.iloc[i,4] ==0 or data.iloc[i,5] ==0:
            print('i',i)
            new_data = new_data.drop([i],axis=0)
            num = num+1
            print('num:',num)
            break
data = new_data
data=data[~(data['a_1'].isin([0]) & data['DBC'].isin([2]))]
data.apply(lambda x : (x-np.min(x))/(np.max(x)-np.min(x)))

'''
#t检验
for k in range(19):
    a=data.iloc[0:286,k]
    b=data.iloc[286:633,k]
    print (stats.ttest_ind(a, b, equal_var=True))
''' 
    
df = pd.DataFrame()
#十折交叉验证
data_1=data.loc[data.label==0]
data_2=data.loc[data.label==1]
i=int(len(data_1) * 0.1)
j=int(len(data_2) * 0.1)
f1=[]
f2=[]
A=[]
for k in range(10):
    data_3=data_1.iloc[k*i:(k+1)*i,:]
    data_3_index = data_3.index.to_list()
    data_4=data_1[~data_1.index.isin(data_3_index)]
        
    data_5=data_2.iloc[k*j:(k+1)*j,:]
    data_5_index = data_5.index.to_list()
    data_6=data_2[~data_2.index.isin(data_5_index)]
        
    data_test=pd.concat([data_3,data_5])#新测试集
    data_train=pd.concat([data_4,data_6])#新训练集
    col_names = data.columns
    #x = data_train[col_names[0:-1]]  # 自变量
    y = data_train[col_names[-1]]  # 因变量
    x=data_train[["DBC","blanket","Box","lacunarity_2"]]
    
    model =rfc()
    model.fit(x, y)
    #x_test = data_test[col_names[0:-1]]  
    x_test=data_test[["DBC","blanket","Box","lacunarity_2"]]
    y_test = data_test[col_names[-1]]
    predict= model.predict(x_test)
    predict=pd.DataFrame(predict)
    df=df.append(predict)
    a=metrics.f1_score(y_test, predict)
    b=P(y_test, predict)#准确率k
    f1.append(a)
    f2.append(b)        
print(f1)
print(f2)  
'''
data_test[["DBC","blanket","Box","lacunarity_2","b_1","b_2","d_2"]]
df=df.values
df=df.reshape(63,10)
df=pd.DataFrame(df)


df['Col_sum'] = df.apply(lambda x: x.sum(),axis=1)#计算行和
for i in 66:
    if df.iloc[i,10]>=7:
        df['new_label']=1
else:
        df['new_label']=0

'''
'''
data_train,data_test = train_test_split(data,test_size=0.2,random_state=1234)
col_names = data.columns
x = data_train[col_names[0:-1]]  # 自变量
y = data_train[col_names[-1]]  # 因变量
#逻辑斯蒂回归

model = LogisticRegression(solver='liblinear')  
model.fit(x, y)
x_test = data_test[col_names[0:-2]]  
y_test = data_test[col_names[-1]]
predict = model.predict(x_test)  # 预测值
a=metrics.f1_score(y_test, predict)
#acu = metrics.scorer.arccuracy_score(y_test,predict)#准确率
AUC=roc_auc_score(y_test, predict)
'''

'''
#支持向量机
model = SVC(kernel = "sigmoid",probability=True)  
model.fit(x, y)
x_test = data_test[col_names[0:-1]]  
y_test = data_test[col_names[-1]]
predict = model.predict(x_test) 
#predict = model.predict_proba(x_test)  # 预测值
a=metrics.f1_score(y_test, predict)
P(y_test, predict)#准确率
R(y_test, predict)#召回率
AUC=roc_auc_score(y_test, predict)

#随机森林
model = rfc()  
model.fit(x, y)
x_test = data_test[col_names[0:-1]]  
y_test = data_test[col_names[-1]]
predict = model.predict(x_test) 
a=metrics.f1_score(y_test, predict)
P(y_test, predict)#准确率
#画ROC曲线
recall=[]
FPR=[]
probrange=np.linspace(predict[:,1].min(),predict[:,1].max(),30,endpoint=False)
for i in probrange:
   y_predict=[]
   for j in range(148):
       if predict[j,1]>i:
           y_predict.append(1)
       else:
           y_predict.append(0)
   cm = CM(y_test, y_predict,labels=[1,0])
   recall.append(cm[0,0]/cm[0,:].sum())
   FPR.append(cm[1,0]/cm[1,:].sum())
recall.sort()
FPR.sort()
plt.plot(FPR,recall,c="red")
plt.plot(probrange+0.05,probrange+0.05,c="black",linestyle="--")
plt.show()
#画图
x1=data.iloc[:,0].values
x2=data.iloc[:,1].values
y1=data.iloc[:,4].values
plt.scatter(x1,x2,c=y1,s=50,cmap="rainbow")#rainbow彩虹色
plt.xticks([])
plt.yticks([])
plt.show()
'''

