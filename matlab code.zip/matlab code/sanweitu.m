I=imread('E:/1/333/361.png');
mysize=size(I)
if numel(mysize)>2
       I=rgb2gray(I)
else
       I=I;
end
I=double(I);
mesh(flipdim(I,1));


